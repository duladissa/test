import numpy as np

basePath = '/Users/duladissa/Desktop/PATH_TEST/local_content/models/architecture/lstm/entities/followup_email_compose_edits'

#1
# Load Labels and save only the entity label
data = np.load(basePath+'/idx2Label.npy', allow_pickle=True).item()

with open(basePath+'/idx2Label.vocab','w') as file:
    for k in (data.keys()):
        file.write("%s\n" % (data[k]))


#2
# Load char2Idx and save only the key
data = np.load(basePath+'/char2Idx.npy', allow_pickle=True).item()
with open(basePath+'/char2Idx.vocab','w') as file:
    for k in (data.keys()):
        file.write("%s\n" % (k))


#3
# Load word2Idx and save only the entity label
data = np.load(basePath+'/word2Idx.npy', allow_pickle=True).item()
with open(basePath+'/word2Idx.vocab','w') as file:
    for k in (data.keys()):
        file.write("%s\n" % (k))
